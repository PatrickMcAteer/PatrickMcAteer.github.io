//
//  main.cpp
//  Chapter 8 Project 11
//
//  Created by Patrick McAteer on 11/23/20.
//  Copyright © 2020 Patrick McAteer. All rights reserved.
//

#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, const char * argv[])

    {
    
    // Objects get declared
        
        const int NROWS{16};
        const int NCOLS{4};
        
    // DB Variable
        
        double power[NROWS][NCOLS];
        double power_sum = 0;
        int dayCounter = 0;
        ifstream data1;
        
    // Input files opened
        
        data1.open("power1.dat");
    
        if(data1.fail())
        
        {
            cerr << "power1.dat could not be opened.\n\nPlease try again.\n\n";
            exit(1);
        }
    
    // Flag format is set
        
        cout.setf(ios::fixed);
        cout.setf(ios::showpoint);
        
    // Precison can be changed
        
        cout.precision(5);
    
    // Two dimensional array
        
        for (int i=0; i<NROWS; ++i)
            {
                for (int j=0; j<NCOLS; ++j)
                {
                    data1 >> power[i][j];
                }
            }
    
    // Total average calculated
        
        for (int j=0; j<NCOLS; ++j)
            
        {
            for (int i=0; i<NROWS; ++i)
                {
                    power_sum += power[i][j];
                }
        }
        
    // Print average
    
        float powerAverage = power_sum/(NROWS * NCOLS);
        
            cout << "The average output is: " << powerAverage << " megawatts" <<endl;
    
    //Check if daily power is higher
        
        for (int j=0; j<NCOLS; ++j)
            {
                for (int i=0; i<NROWS; ++i)
                {
                    if (power[i][j] > powerAverage)
                        dayCounter++;
                }
            }
        
    // Print daily power ouput
        
        cout << "The number of days above the average power output is " << dayCounter << endl;
    
    // Program exit
        
    data1.close();
    
    return 0;
}
