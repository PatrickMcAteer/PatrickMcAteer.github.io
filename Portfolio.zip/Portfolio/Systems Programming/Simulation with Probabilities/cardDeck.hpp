//
//  cardDeck.hpp
//  Simulation with Probabilities
//
//  Created by Patrick McAteer on 12/3/20.
//  Copyright © 2020 Patrick McAteer. All rights reserved.
//

#ifndef CARDDECK_H
#define CARDDECK_H
/* CardDeck class declaration */
/* filename: CardDeck.h */
#include "card.hpp" //Required for Card
#include <vector> //Required for vector */
using namespace std;
class CardDeck {
public:
    CardDeck();
    void shuffleDeck();
    Card draw();
private:
    vector<Card> theDeck;
    vector<Card> deltCards;
};
#endif
