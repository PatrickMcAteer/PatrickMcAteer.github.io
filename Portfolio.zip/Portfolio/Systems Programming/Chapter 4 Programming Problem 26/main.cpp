//
//  main.cpp
//  Chapter 4 Programming Problem 26
//
//  Created by Patrick McAteer on 11/06/20.
//  Copyright © 2020 Patrick McAteer. All rights reserved.
//

// Converting Fahrenheit (°F) to Celsius (C°)

// Same style as Inches to Centimeters

#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, const char * argv[])

{
    
    // Initialise stated variables
    
    double fahrenheit (0.0), celsius;
    
    // Prepare output format
    
    cout.setf(ios::fixed);
    cout.precision(4);
    
    // Table will appear in two columns
    
    cout << "Fahrenheit (°F) to Celsius (C°): \n";
    
    // Convert to C° Cand present in table
    
    while (fahrenheit <= 100)
        
    {
        // Convert Inches to Centimeters
        
        celsius = (fahrenheit - 32.0) * (5.0/9.0);
        
        // Print in a table
        
        cout << setw(6) << fahrenheit << setw(10) << celsius << endl;
        
        // Increment fahrenheit evrey 5.0 degrees
        
        fahrenheit = fahrenheit + 5.0;
    }
    
    return 0;
}
